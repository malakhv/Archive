//---------------------------------------------------------------------------
#ifndef dstH
#define dstH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class Tdsts : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
    __fastcall Tdsts(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tdsts *dsts;
//---------------------------------------------------------------------------
#endif
