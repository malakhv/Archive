//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "dtForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TdtTreeForm *dtTreeForm;
//---------------------------------------------------------------------------
__fastcall TdtTreeForm::TdtTreeForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

