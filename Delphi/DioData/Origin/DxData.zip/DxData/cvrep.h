//---------------------------------------------------------------------------
#ifndef cvrepH
#define cvrepH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>
#include <QuickRpt.hpp>
#include <QRCtrls.hpp>
//---------------------------------------------------------------------------
class TcValsRep : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *vRep;
        TQRShape *QRShape54;
        TQRShape *QRShape53;
        TQRShape *QRShape52;
        TQRShape *QRShape51;
        TQRShape *QRShape50;
        TQRShape *QRShape49;
        TQRShape *QRShape48;
        TQRShape *QRShape47;
        TQRShape *QRShape2;
        TQRShape *QRShape46;
        TQRShape *QRShape45;
        TQRShape *QRShape44;
        TQRShape *QRShape43;
        TQRShape *QRShape1;
        TQRShape *QRShape42;
        TQRShape *QRShape41;
        TQRShape *QRShape40;
        TQRShape *QRShape35;
        TQRShape *QRShape39;
        TQRShape *QRShape38;
        TQRShape *QRShape37;
        TQRShape *QRShape36;
        TQRShape *QRShape34;
        TQRShape *QRShape33;
        TQRShape *QRShape32;
        TQRShape *QRShape31;
        TQRShape *QRShape30;
        TQRShape *QRShape29;
        TQRShape *QRShape28;
        TQRShape *QRShape23;
        TQRShape *QRShape22;
        TQRShape *QRShape21;
        TQRShape *QRShape20;
        TQRShape *QRShape27;
        TQRShape *QRShape26;
        TQRShape *QRShape25;
        TQRShape *QRShape24;
        TQRShape *QRShape19;
        TQRShape *QRShape18;
        TQRShape *QRShape16;
        TQRShape *QRShape17;
        TQRShape *QRShape15;
        TQRShape *QRShape10;
        TQRShape *QRShape12;
        TQRShape *QRShape9;
        TQRShape *QRShape7;
        TQRLabel *qlq;
        TQRLabel *QRLabel3;
        TQRLabel *QRLabel4;
        TQRLabel *QRLabel5;
        TQRLabel *QRLabel6;
        TQRLabel *qlv1;
        TQRLabel *qlv2;
        TQRLabel *qlv3;
        TQRLabel *qlv4;
        TQRLabel *QRLabel11;
        TQRLabel *QRLabel12;
        TQRLabel *qlm1;
        TQRLabel *qlm2;
        TQRLabel *QRLabel7;
        TQRLabel *qld;
        TQRLabel *qln;
        TQRLabel *QRLabel8;
        TQRLabel *qlh;
        TQRLabel *QRLabel9;
        TQRLabel *qlb;
        TQRLabel *QRLabel10;
        TQRLabel *qta;
        TQRLabel *QRLabel13;
        TQRLabel *qlt1;
        TQRLabel *qlt2;
        TQRLabel *QRLabel15;
        TQRLabel *QRLabel20;
        TQRLabel *qlk1;
        TQRLabel *qlk2;
        TQRLabel *qlk3;
        TQRLabel *qlk4;
        TQRLabel *QRLabel21;
        TQRShape *QRShape4;
        TQRShape *QRShape5;
        TQRLabel *QRLabel22;
        TQRLabel *QRLabel23;
        TQRShape *QRShape6;
        TQRLabel *QRLabel24;
        TQRShape *QRShape3;
        TQRShape *QRShape8;
        TQRLabel *QRLabel2;
        TQRLabel *QRLabel25;
        TQRShape *QRShape11;
        TQRLabel *QRLabel26;
        TQRShape *QRShape13;
        TQRShape *QRShape14;
        TQRLabel *QRLabel27;
        TQRLabel *QRLabel28;
        TQRLabel *QRLabel14;
        TQRLabel *QRLabel29;
        TQRLabel *QRLabel30;
        TQRLabel *QRLabel31;
        TQRLabel *QRLabel32;
        TQRLabel *QRLabel33;
        TQRLabel *QRLabel16;
        TQRLabel *QRLabel17;
        TQRLabel *QRLabel18;
        TQRLabel *QRLabel19;
        TQRLabel *QRLabel34;
        TQRLabel *QRLabel35;
        TQRLabel *QRLabel36;
        TQRLabel *QRLabel37;
        TQRLabel *QRLabel38;
        TQRLabel *QRLabel39;
        TQRLabel *QRLabel40;
        TQRStringsBand *qh1;
        TQRExpr *QRExpr1;
private:	// User declarations
public:		// User declarations
    __fastcall TcValsRep(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TcValsRep *cValsRep;
//---------------------------------------------------------------------------
#endif
